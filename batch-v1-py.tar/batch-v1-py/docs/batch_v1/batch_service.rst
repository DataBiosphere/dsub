BatchService
------------------------------

.. automodule:: google.cloud.batch_v1.services.batch_service
    :members:
    :inherited-members:

.. automodule:: google.cloud.batch_v1.services.batch_service.pagers
    :members:
    :inherited-members:
