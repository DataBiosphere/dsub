Types for Google Cloud Batch v1 API
===================================

.. automodule:: google.cloud.batch_v1.types
    :members:
    :undoc-members:
    :show-inheritance:
