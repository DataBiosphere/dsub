Types for Google Cloud Batch v1alpha1 API
=========================================

.. automodule:: google.cloud.batch_v1alpha1.types
    :members:
    :undoc-members:
    :show-inheritance:
