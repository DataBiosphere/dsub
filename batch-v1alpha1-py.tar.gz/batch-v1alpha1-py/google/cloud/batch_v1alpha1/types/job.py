# -*- coding: utf-8 -*-
# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import proto  # type: ignore

from google.cloud.batch_v1alpha1.types import task
from google.protobuf import duration_pb2  # type: ignore
from google.protobuf import timestamp_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.batch.v1alpha1',
    manifest={
        'Job',
        'LogsPolicy',
        'JobDependency',
        'JobStatus',
        'JobNotification',
        'AllocationPolicy',
        'TaskGroup',
    },
)


class Job(proto.Message):
    r"""The Cloud Batch Job description.

    Attributes:
        name (str):
            Job name. It must have the format of
            "projects/*/locations/*/jobs/*". For example:
            "projects/123456/locations/us-west1/jobs/job01".
        uid (str):
            Output only. A system generated unique ID (in
            UUID4 format) for the Job.
        priority (int):
            Priority of the Job. The valid value range is [0, 100). A
            job with higher priority value will be scheduled to run
            earlier.
        task_groups (Sequence[google.cloud.batch_v1alpha1.types.TaskGroup]):
            Required. TaskGroups in the Job. Only one
            TaskGroup is supported now.
        scheduling_policy (google.cloud.batch_v1alpha1.types.Job.SchedulingPolicy):
            Scheduling policy for TaskGroups in the job.
        dependencies (Sequence[google.cloud.batch_v1alpha1.types.JobDependency]):
            At least one of the dependencies must be satisfied before
            the Job is scheduled to run. Only one JobDependency is
            supported now. [NotImplemented]
        allocation_policy (google.cloud.batch_v1alpha1.types.AllocationPolicy):
            Compute resource allocation for all
            TaskGroups in the Job.
        labels (Sequence[google.cloud.batch_v1alpha1.types.Job.LabelsEntry]):
            Labels for the Job. Labels could be user provided or system
            generated. For example, "labels": { "department": "finance",
            "environment": "test" } You can assign up to 64 labels.
            `Google Compute Engine label
            restrictions <https://cloud.google.com/compute/docs/labeling-resources#restrictions>`__
            apply. Label names that start with "goog-" or "google-" are
            reserved.
        status (google.cloud.batch_v1alpha1.types.JobStatus):
            Output only. Job status. It is read only for
            users.
        notification (google.cloud.batch_v1alpha1.types.JobNotification):
            Job notification.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            When the Job was created.
        update_time (google.protobuf.timestamp_pb2.Timestamp):
            The last time the Job was updated.
        logs_policy (google.cloud.batch_v1alpha1.types.LogsPolicy):
            Log preservation policy for the Job.
        notifications (Sequence[google.cloud.batch_v1alpha1.types.JobNotification]):
            Notification configurations.
    """
    class SchedulingPolicy(proto.Enum):
        r"""The order that TaskGroups are scheduled relative to each other.

        [NotImplemented]
        """
        SCHEDULING_POLICY_UNSPECIFIED = 0
        AS_SOON_AS_POSSIBLE = 1

    name = proto.Field(
        proto.STRING,
        number=1,
    )
    uid = proto.Field(
        proto.STRING,
        number=2,
    )
    priority = proto.Field(
        proto.INT64,
        number=3,
    )
    task_groups = proto.RepeatedField(
        proto.MESSAGE,
        number=4,
        message='TaskGroup',
    )
    scheduling_policy = proto.Field(
        proto.ENUM,
        number=5,
        enum=SchedulingPolicy,
    )
    dependencies = proto.RepeatedField(
        proto.MESSAGE,
        number=6,
        message='JobDependency',
    )
    allocation_policy = proto.Field(
        proto.MESSAGE,
        number=7,
        message='AllocationPolicy',
    )
    labels = proto.MapField(
        proto.STRING,
        proto.STRING,
        number=8,
    )
    status = proto.Field(
        proto.MESSAGE,
        number=9,
        message='JobStatus',
    )
    notification = proto.Field(
        proto.MESSAGE,
        number=10,
        message='JobNotification',
    )
    create_time = proto.Field(
        proto.MESSAGE,
        number=11,
        message=timestamp_pb2.Timestamp,
    )
    update_time = proto.Field(
        proto.MESSAGE,
        number=12,
        message=timestamp_pb2.Timestamp,
    )
    logs_policy = proto.Field(
        proto.MESSAGE,
        number=13,
        message='LogsPolicy',
    )
    notifications = proto.RepeatedField(
        proto.MESSAGE,
        number=14,
        message='JobNotification',
    )


class LogsPolicy(proto.Message):
    r"""LogsPolicy describes how outputs from a Job's Tasks
    (stdout/stderr) will be preserved.

    Attributes:
        destination (google.cloud.batch_v1alpha1.types.LogsPolicy.Destination):
            Where logs should be saved.
        logs_path (str):
            The path to which logs are saved when the
            destination = PATH. This can be a local filepath
            on the VM, or under the mount point of a
            Persistent Disk or Filestore, or a Cloud Storage
            path.
    """
    class Destination(proto.Enum):
        r"""The destination (if any) for logs."""
        DESTINATION_UNSPECIFIED = 0
        CLOUD_LOGGING = 1
        PATH = 2

    destination = proto.Field(
        proto.ENUM,
        number=1,
        enum=Destination,
    )
    logs_path = proto.Field(
        proto.STRING,
        number=2,
    )


class JobDependency(proto.Message):
    r"""JobDependency describes the state of other Jobs that the
    start of this Job depends on.
    All dependent Jobs must have been submitted in the same region.

    Attributes:
        items (Sequence[google.cloud.batch_v1alpha1.types.JobDependency.ItemsEntry]):
            Each item maps a Job name to a Type.
            All items must be satisfied for the
            JobDependency to be satisfied (the AND
            operation).
            Once a condition for one item becomes true, it
            won't go back to false even the dependent Job
            state changes again.
    """
    class Type(proto.Enum):
        r"""Dependency type."""
        TYPE_UNSPECIFIED = 0
        SUCCEEDED = 1
        FAILED = 2
        FINISHED = 3

    items = proto.MapField(
        proto.STRING,
        proto.ENUM,
        number=1,
        enum=Type,
    )


class JobStatus(proto.Message):
    r"""Job status.

    Attributes:
        state (google.cloud.batch_v1alpha1.types.JobStatus.State):
            Job state
        status_events (Sequence[google.cloud.batch_v1alpha1.types.StatusEvent]):
            Job status events
        task_groups (Sequence[google.cloud.batch_v1alpha1.types.JobStatus.TaskGroupsEntry]):
            Aggregated task status for each TaskGroup in
            the Job. The map key is TaskGroup ID.
        run_duration (google.protobuf.duration_pb2.Duration):
            The duration of time the Job is in status
            RUNNING. Once the Job completes (i.e. the Job
            status is either SUCCEEDED/FAILED) the run
            duration represents the time it took the Job to
            complete.
    """
    class State(proto.Enum):
        r"""Valid Job states."""
        STATE_UNSPECIFIED = 0
        QUEUED = 1
        SCHEDULED = 2
        RUNNING = 3
        SUCCEEDED = 4
        FAILED = 5
        DELETION_IN_PROGRESS = 6

    class TaskGroupStatus(proto.Message):
        r"""Aggregated task status for a TaskGroup.

        Attributes:
            counts (Sequence[google.cloud.batch_v1alpha1.types.JobStatus.TaskGroupStatus.CountsEntry]):
                Count of task in each state in the TaskGroup.
                The map key is task state name.
        """

        counts = proto.MapField(
            proto.STRING,
            proto.INT64,
            number=1,
        )

    state = proto.Field(
        proto.ENUM,
        number=1,
        enum=State,
    )
    status_events = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message=task.StatusEvent,
    )
    task_groups = proto.MapField(
        proto.STRING,
        proto.MESSAGE,
        number=4,
        message=TaskGroupStatus,
    )
    run_duration = proto.Field(
        proto.MESSAGE,
        number=5,
        message=duration_pb2.Duration,
    )


class JobNotification(proto.Message):
    r"""Notification configurations.

    Attributes:
        pubsub_topic (str):
            The Pub/Sub topic where notifications like the job state
            changes will be published. This topic should be an existing
            topic in the same project with the job and billings will be
            charged to this project. If no topic is specified, there
            will be no Pub/Sub messages sent. Topic format is
            ``projects/{project}/topics/{topic}``.
        message (google.cloud.batch_v1alpha1.types.JobNotification.Message):
            The message caters the message attributes
            configuration will to be sent to this Pub/Sub
            topic. Without this field, there is no message
            being sent by default.
    """
    class Type(proto.Enum):
        r"""The message type."""
        TYPE_UNSPECIFIED = 0
        JOB_STATE_CHANGED = 1
        TASK_STATE_CHANGED = 2

    class Message(proto.Message):
        r"""Message details.
        Describe a list of attributes this message should have. Without
        specified message attributes, no message will be sent by
        default.

        Attributes:
            type_ (google.cloud.batch_v1alpha1.types.JobNotification.Type):
                The message type.
            new_job_state (google.cloud.batch_v1alpha1.types.JobStatus.State):
                The new job state.
            new_task_state (google.cloud.batch_v1alpha1.types.TaskStatus.State):
                The new task state.
        """

        type_ = proto.Field(
            proto.ENUM,
            number=1,
            enum='JobNotification.Type',
        )
        new_job_state = proto.Field(
            proto.ENUM,
            number=2,
            enum='JobStatus.State',
        )
        new_task_state = proto.Field(
            proto.ENUM,
            number=3,
            enum=task.TaskStatus.State,
        )

    pubsub_topic = proto.Field(
        proto.STRING,
        number=1,
    )
    message = proto.Field(
        proto.MESSAGE,
        number=2,
        message=Message,
    )


class AllocationPolicy(proto.Message):
    r"""A Job's resource allocation policy describes when, where, and
    how compute resources should be allocated for the Job.

    Attributes:
        location (google.cloud.batch_v1alpha1.types.AllocationPolicy.LocationPolicy):
            Location where compute resources should be
            allocated for the Job.
        instance (google.cloud.batch_v1alpha1.types.AllocationPolicy.InstancePolicy):
            Create only instances allowed by this policy.
        instance_templates (Sequence[str]):
            Create instances from the first instance template - MVP Use
            'gcloud compute instance-templates list\` to see available
            templates in the project If specified, it overrides the
            'instance' field.
        provisioning_models (Sequence[google.cloud.batch_v1alpha1.types.AllocationPolicy.ProvisioningModel]):
            Create only instances in the listed provisiong models.
            Default to allow all.

            Currently only the first model of the provisioning_models
            list will be considered; specifying additional models (e.g.,
            2nd, 3rd, etc.) is a no-op.
        service_account (str):
            Email of the service account that VMs will
            run as.
        labels (Sequence[google.cloud.batch_v1alpha1.types.AllocationPolicy.LabelsEntry]):
            Labels applied to all VM instances and other resources
            created by AllocationPolicy. Labels could be user provided
            or system generated. You can assign up to 64 labels. `Google
            Compute Engine label
            restrictions <https://cloud.google.com/compute/docs/labeling-resources#restrictions>`__
            apply. Label names that start with "goog-" or "google-" are
            reserved.
        network (google.cloud.batch_v1alpha1.types.AllocationPolicy.NetworkPolicy):
            The network policy.
    """
    class ProvisioningModel(proto.Enum):
        r"""Compute Engine VM instance provisioning model."""
        PROVISIONING_MODEL_UNSPECIFIED = 0
        STANDARD = 1
        SPOT = 2
        PREEMPTIBLE = 3

    class LocationPolicy(proto.Message):
        r"""Be consistent with LocationPolicy in
        //cloud/cluster/api/mixter_instances.proto.

        Attributes:
            allowed_locations (Sequence[str]):
                A list of allowed location names represented
                by internal URLs, for example,
                zones/us-central1-a, regions/us-west1. First
                location in the list should be a region.
            denied_locations (Sequence[str]):
                A list of denied location names.
        """

        allowed_locations = proto.RepeatedField(
            proto.STRING,
            number=1,
        )
        denied_locations = proto.RepeatedField(
            proto.STRING,
            number=2,
        )

    class InstancePolicy(proto.Message):
        r"""InstancePolicy describes what instances should be created for
        the Job.

        Attributes:
            allowed_machine_types (Sequence[str]):
                A list of allowed Compute Engine machine
                types, for example, e2-standard-4. Default is
                empty which means allowing all.
            denied_machine_types (Sequence[str]):
                A list of denied Compute Engine machine types. Default is
                empty which means denying none. A machine type is allowed if
                it matches 'allowed_machine_types' AND does not match
                'denied_machine_types'. For example, allowed_machine_types =
                "e2-standard" denied_machine_types = "e2-standard-2,
                e2-standard-4" means using all E2 standard machine types
                except for 'e2-standard-2' and 'e2-standard-4.

                [NotImplemented]
            allowed_cpu_platforms (Sequence[str]):
                A list of allowed CPU platforms, for example, "Intel Cascade
                Lake", "AMD Rome". Default is empty which means allowing
                all.

                [NotImplemented]
            denied_cpu_platforms (Sequence[str]):
                A list of denied CPU platforms. Default is empty which means
                denying none. A CPU platform is allowed if it matches
                'allowed_cpu_platforms' AND does not match
                'denied_cpu_platforms'. If a CPU platform belongs to both
                lists, it will be denied.

                [NotImplemented]
            allowed_accelerator_types (Sequence[str]):
                A list of allowed accelerator types (GPU models), for
                example, "nvidia-tesla-t4". Default is empty which means
                allowing all.

                [NotImplemented]
            denied_accelerator_types (Sequence[str]):
                A list of denied accelerator types (GPU models). Default is
                empty which means denying none. A accelerator type is
                allowed if it matches 'allowed_accelerator_types' AND does
                not match 'denied__accelerator_types'.

                [NotImplemented]
            accelerator_count (int):
                The number of accelerators per VM instance.

                [NotImplemented]
        """

        allowed_machine_types = proto.RepeatedField(
            proto.STRING,
            number=1,
        )
        denied_machine_types = proto.RepeatedField(
            proto.STRING,
            number=2,
        )
        allowed_cpu_platforms = proto.RepeatedField(
            proto.STRING,
            number=3,
        )
        denied_cpu_platforms = proto.RepeatedField(
            proto.STRING,
            number=4,
        )
        allowed_accelerator_types = proto.RepeatedField(
            proto.STRING,
            number=5,
        )
        denied_accelerator_types = proto.RepeatedField(
            proto.STRING,
            number=6,
        )
        accelerator_count = proto.Field(
            proto.INT64,
            number=7,
        )

    class NetworkInterface(proto.Message):
        r"""A network interface.

        Attributes:
            network (str):
                The URL of the network resource.
            subnetwork (str):
                The URL of the Subnetwork resource.
            no_external_ip_address (bool):
                Default is false (with an external IP
                address). Required if no external public IP
                address is attached to the VM. If no external
                public IP address, additional configuration is
                required to allow the VM to access Google
                Services. See
                https://cloud.google.com/vpc/docs/configure-private-google-access
                and
                https://cloud.google.com/nat/docs/gce-example#create-nat
                for more information.
        """

        network = proto.Field(
            proto.STRING,
            number=1,
        )
        subnetwork = proto.Field(
            proto.STRING,
            number=2,
        )
        no_external_ip_address = proto.Field(
            proto.BOOL,
            number=3,
        )

    class NetworkPolicy(proto.Message):
        r"""NetworkPolicy describes network configurations for instances
        created for the job.

        Attributes:
            network_interfaces (Sequence[google.cloud.batch_v1alpha1.types.AllocationPolicy.NetworkInterface]):
                Network configurations.
        """

        network_interfaces = proto.RepeatedField(
            proto.MESSAGE,
            number=1,
            message='AllocationPolicy.NetworkInterface',
        )

    location = proto.Field(
        proto.MESSAGE,
        number=1,
        message=LocationPolicy,
    )
    instance = proto.Field(
        proto.MESSAGE,
        number=2,
        message=InstancePolicy,
    )
    instance_templates = proto.RepeatedField(
        proto.STRING,
        number=3,
    )
    provisioning_models = proto.RepeatedField(
        proto.ENUM,
        number=4,
        enum=ProvisioningModel,
    )
    service_account = proto.Field(
        proto.STRING,
        number=5,
    )
    labels = proto.MapField(
        proto.STRING,
        proto.STRING,
        number=6,
    )
    network = proto.Field(
        proto.MESSAGE,
        number=7,
        message=NetworkPolicy,
    )


class TaskGroup(proto.Message):
    r"""A TaskGroup contains one or multiple Tasks that share the
    same Runnable but with different runtime parameters.

    Attributes:
        name (str):
            Output only. TaskGroup name.
            The system generates this field based on parent
            Job name. For example:
            "projects/123456/locations/us-west1/jobs/job01/taskGroups/default-group".
        task_spec (google.cloud.batch_v1alpha1.types.TaskSpec):
            Required. Tasks in the group share the same
            task spec.
        task_count (int):
            Number of Tasks in the TaskGroup.
            default is 1
        parallelism (int):
            Max number of tasks that can run in parallel. Default to
            min(task_count, 1000).
        scheduling_policy (google.cloud.batch_v1alpha1.types.TaskGroup.SchedulingPolicy):
            Scheduling policy for Tasks in the TaskGroup.
        allocation_policy (google.cloud.batch_v1alpha1.types.AllocationPolicy):
            Compute resource allocation for the
            TaskGroup. If specified, it overrides resources
            in Job.
        labels (Sequence[google.cloud.batch_v1alpha1.types.TaskGroup.LabelsEntry]):
            Labels for the TaskGroup. Labels could be user provided or
            system generated. You can assign up to 64 labels. `Google
            Compute Engine label
            restrictions <https://cloud.google.com/compute/docs/labeling-resources#restrictions>`__
            apply. Label names that start with "goog-" or "google-" are
            reserved.
        task_environments (Sequence[google.cloud.batch_v1alpha1.types.TaskGroup.Environment]):
            An array of environment variable mappings, which are passed
            to Tasks with matching indices. If task_environments is used
            then task_count should not be specified in the request (and
            will be ignored). Task count will be the length of
            task_environments.

            Tasks get a BATCH_TASK_INDEX and BATCH_TASK_COUNT
            environment variable, in addition to any environment
            variables set in task_environments, specifying the number of
            Tasks in the Task's parent TaskGroup, and the specific
            Task's index in the TaskGroup (0 through BATCH_TASK_COUNT -
            1).

            task_environments supports up to 200 entries.
        task_count_per_node (int):
            Max number of tasks that can be run on a node
            at the same time. Default is 1.
        require_hosts_file (bool):
            When true, Batch will populate a file with a list of all VMs
            assigned to the TaskGroup and set the BATCH_HOSTS_FILE
            environment variable to the path of that file. Defaults to
            false.
    """
    class SchedulingPolicy(proto.Enum):
        r"""How Tasks in the TaskGroup should be scheduled relative to
        each other.
        """
        SCHEDULING_POLICY_UNSPECIFIED = 0
        AS_SOON_AS_POSSIBLE = 1

    class Environment(proto.Message):
        r"""TaskGroup.Environment is a workaround for proto3 not
        supporting repeated map<string, string>.

        Attributes:
            variables (Sequence[google.cloud.batch_v1alpha1.types.TaskGroup.Environment.VariablesEntry]):
                An map of environment variable names to
                values. The map may contain at most 10 key/value
                pairs with keys length up to 64 characters and
                values up to 4 KB.
        """

        variables = proto.MapField(
            proto.STRING,
            proto.STRING,
            number=1,
        )

    name = proto.Field(
        proto.STRING,
        number=1,
    )
    task_spec = proto.Field(
        proto.MESSAGE,
        number=3,
        message=task.TaskSpec,
    )
    task_count = proto.Field(
        proto.INT64,
        number=4,
    )
    parallelism = proto.Field(
        proto.INT64,
        number=5,
    )
    scheduling_policy = proto.Field(
        proto.ENUM,
        number=6,
        enum=SchedulingPolicy,
    )
    allocation_policy = proto.Field(
        proto.MESSAGE,
        number=7,
        message='AllocationPolicy',
    )
    labels = proto.MapField(
        proto.STRING,
        proto.STRING,
        number=8,
    )
    task_environments = proto.RepeatedField(
        proto.MESSAGE,
        number=9,
        message=Environment,
    )
    task_count_per_node = proto.Field(
        proto.INT64,
        number=10,
    )
    require_hosts_file = proto.Field(
        proto.BOOL,
        number=11,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
